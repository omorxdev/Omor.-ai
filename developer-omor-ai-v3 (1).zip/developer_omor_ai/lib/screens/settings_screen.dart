import 'package:flutter/material.dart';
import 'package:permission_handler/permission_handler.dart';
import 'app_shell.dart';
import '../services/app_config.dart';
import '../services/owner_unlock_service.dart';
import '../services/permission_service.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});
  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  final url = TextEditingController();
  final secret = TextEditingController();
  String status = '';

  @override
  void initState() {
    super.initState();
    AppConfig.baseUrl().then((v) => mounted ? setState(() => url.text = v) : null);
  }

  Future<void> saveAndUnlock() async {
    await AppConfig.setBaseUrl(url.text);
    final err = secret.text.isEmpty ? null : await OwnerUnlockService().unlock(secret.text);
    if (secret.text.isNotEmpty && err == null) secret.clear();
    if (!mounted) return;
    setState(() => status = err ?? 'সেভ হয়েছে ✅');
  }


  Future<void> grantAll() async {
    await PermissionService.requestAll();
    if (await PermissionService.anyPermanentlyDenied()) {
      await openAppSettings();
    }
    if (mounted) setState(() => status = 'পারমিশন চেক সম্পন্ন');
  }

  @override
  Widget build(BuildContext context) => Column(children: [
        const PageHeader(subtitle: 'CONFIGURATION'),
        Expanded(
            child: ListView(padding: const EdgeInsets.all(16), children: [
          TextField(controller: url, keyboardType: TextInputType.url, decoration: const InputDecoration(labelText: 'Server URL (https://...)')),
          const SizedBox(height: 12),
          TextField(controller: secret, obscureText: true, decoration: const InputDecoration(labelText: 'Owner secret code')),
          const SizedBox(height: 12),
          FilledButton(onPressed: saveAndUnlock, child: const Text('Save & Unlock')),
          const SizedBox(height: 8),
          OutlinedButton.icon(onPressed: grantAll, icon: const Icon(Icons.verified_user_outlined), label: const Text('সব Permission Allow করো')),
          if (status.isNotEmpty) Padding(padding: const EdgeInsets.only(top: 12), child: Text(status)),
          const SizedBox(height: 16),
          const Text('DEVELOPER OMOR AI • 0.2.0', style: TextStyle(color: Colors.white38, fontSize: 12)),
        ])),
      ]);
}
