import 'package:flutter/material.dart';
import 'package:flutter_contacts/flutter_contacts.dart';
import 'app_shell.dart';
import '../services/whatsapp_service.dart';

class ToolsScreen extends StatelessWidget {
  const ToolsScreen({super.key});

  Future<void> _whatsapp(BuildContext context) async {
    final phone = TextEditingController();
    final msg = TextEditingController();
    await showDialog(
        context: context,
        builder: (ctx) => AlertDialog(
              title: const Text('WhatsApp মেসেজ'),
              content: Column(mainAxisSize: MainAxisSize.min, children: [
                TextField(controller: phone, keyboardType: TextInputType.phone, decoration: const InputDecoration(labelText: 'নম্বর (দেশের কোড সহ, 8801...)')),
                TextButton.icon(
                    onPressed: () async {
                      if (await FlutterContacts.requestPermission(readonly: true)) {
                        final c = await FlutterContacts.openExternalPick();
                        if (c != null && c.phones.isNotEmpty) phone.text = c.phones.first.number;
                      }
                    },
                    icon: const Icon(Icons.contacts_outlined),
                    label: const Text('Contact থেকে নাও')),
                TextField(controller: msg, minLines: 1, maxLines: 4, decoration: const InputDecoration(labelText: 'মেসেজ')),
              ]),
              actions: [
                TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
                FilledButton(
                    onPressed: () async {
                      final ok = await WhatsAppService.compose(phone.text, msg.text);
                      if (ctx.mounted) Navigator.pop(ctx);
                      if (!ok && context.mounted) {
                        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('WhatsApp খোলা যায়নি')));
                      }
                    },
                    child: const Text('WhatsApp খোলো')),
              ],
            ));
  }

  @override
  Widget build(BuildContext context) => Column(children: [
        const PageHeader(subtitle: 'AI TOOLBOX'),
        Expanded(
            child: ListView(padding: const EdgeInsets.all(16), children: [
          Card(
              color: const Color(0xFF141827),
              child: ListTile(
                leading: const CircleAvatar(backgroundColor: Color(0xFF302B59), child: Icon(Icons.send, color: Color(0xFFB8AEFF))),
                title: const Text('WhatsApp মেসেজ', style: TextStyle(fontWeight: FontWeight.w700)),
                subtitle: const Text('Contact বেছে মেসেজ তৈরি করো', style: TextStyle(color: Colors.white54)),
                onTap: () => _whatsapp(context),
              )),
        ])),
      ]);
}
