import 'package:flutter/material.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:speech_to_text/speech_to_text.dart';
import 'app_shell.dart';
import '../services/api_client.dart';

class VoiceScreen extends StatefulWidget {
  const VoiceScreen({super.key});
  @override
  State<VoiceScreen> createState() => _VoiceScreenState();
}

class _VoiceScreenState extends State<VoiceScreen> {
  final stt = SpeechToText();
  final tts = FlutterTts();
  bool listening = false, busy = false;
  String heard = '', reply = '';

  Future<void> toggle() async {
    if (listening) {
      await stt.stop();
      setState(() => listening = false);
      return;
    }
    await tts.stop();
    final mic = await Permission.microphone.request();
    if (!mic.isGranted) {
      setState(() => reply = 'মাইক্রোফোন পারমিশন দরকার। Settings থেকে Allow করো।');
      return;
    }
    final ok = await stt.initialize(
      onStatus: (s) {
        if ((s == 'done' || s == 'notListening') && mounted) setState(() => listening = false);
      },
      onError: (e) {
        if (mounted) setState(() { listening = false; reply = 'Voice error: ${e.errorMsg}'; });
      },
    );
    if (!ok) {
      setState(() => reply = 'এই ফোনে Speech recognition পাওয়া যাচ্ছে না (Google app/Speech Services ইনস্টল আছে?).');
      return;
    }
    final locales = await stt.locales();
    final bn = locales.where((l) => l.localeId.toLowerCase().startsWith('bn')).toList();
    setState(() { listening = true; heard = ''; });
    await stt.listen(
      localeId: bn.isNotEmpty ? bn.first.localeId : null,
      onResult: (r) {
        setState(() => heard = r.recognizedWords);
        if (r.finalResult && r.recognizedWords.trim().isNotEmpty) ask(r.recognizedWords);
      },
    );
  }

  Future<void> ask(String text) async {
    if (busy) return;
    setState(() { busy = true; listening = false; });
    String r;
    try {
      r = await ApiClient.shared.sendChat(text);
    } catch (e) {
      r = e.toString().replaceFirst('Exception: ', '');
    }
    if (!mounted) return;
    setState(() { reply = r; busy = false; });
    await tts.setLanguage('bn-BD');
    await tts.speak(r);
  }

  @override
  void dispose() {
    stt.cancel();
    tts.stop();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => Column(children: [
        const PageHeader(subtitle: 'VOICE ASSISTANT'),
        const Spacer(),
        Container(
            width: 190, height: 190,
            decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: const RadialGradient(colors: [Color(0xFF5E50B8), Color(0xFF151A2B)]),
                boxShadow: [BoxShadow(color: const Color(0xFF8B7CFF).withOpacity(listening ? .5 : .24), blurRadius: 55, spreadRadius: 8)]),
            child: Icon(busy ? Icons.hourglass_top : Icons.graphic_eq, size: 80, color: Colors.white)),
        const SizedBox(height: 24),
        Text(listening ? 'শুনছি...' : busy ? 'ভাবছি...' : 'Omor AI Voice',
            style: const TextStyle(fontSize: 23, fontWeight: FontWeight.bold)),
        if (heard.isNotEmpty)
          Padding(padding: const EdgeInsets.fromLTRB(24, 10, 24, 0), child: Text('"$heard"', textAlign: TextAlign.center, style: const TextStyle(color: Colors.white70))),
        if (reply.isNotEmpty)
          Padding(padding: const EdgeInsets.fromLTRB(24, 10, 24, 0), child: Text(reply, textAlign: TextAlign.center, maxLines: 6, overflow: TextOverflow.ellipsis)),
        const Spacer(),
        Padding(
            padding: const EdgeInsets.only(bottom: 44),
            child: FilledButton.icon(
              onPressed: busy ? null : toggle,
              icon: Icon(listening ? Icons.stop : Icons.mic),
              label: Text(listening ? 'Stop listening' : 'Start voice chat'),
              style: FilledButton.styleFrom(padding: const EdgeInsets.symmetric(horizontal: 28, vertical: 18)),
            )),
      ]);
}
