import 'dart:async';
import 'dart:convert';
import 'package:http/http.dart' as http;
import 'app_config.dart';
import 'owner_unlock_service.dart';

/// Provider keys stay on the server. The app only calls this API.
class ApiClient {
  ApiClient._();
  static final shared = ApiClient._();
  final _client = http.Client();
  String? conversationId;

  Future<String> sendChat(String message) async {
    final base = await AppConfig.baseUrl();
    if (base.isEmpty) {
      throw Exception('Settings-এ Server URL দাও (https://...).');
    }
    final token = await OwnerUnlockService().readOwnerToken();
    if (token == null) {
      throw Exception('Settings-এ গিয়ে Owner Unlock করো।');
    }
    try {
      final r = await _client
          .post(
            Uri.parse('$base/v1/chat'),
            headers: {'Content-Type': 'application/json; charset=utf-8', 'Authorization': 'Bearer $token'},
            body: jsonEncode({'message': message, 'conversation_id': conversationId, 'mode': await AppConfig.mode()}),
          )
          .timeout(const Duration(seconds: 60));
      if (r.statusCode == 401) {
        await OwnerUnlockService().lock();
        throw Exception('Token মেয়াদ শেষ। আবার Owner Unlock করো।');
      }
      if (r.statusCode < 200 || r.statusCode >= 300) {
        throw Exception('Server error (${r.statusCode}).');
      }
      final d = jsonDecode(utf8.decode(r.bodyBytes)) as Map<String, dynamic>;
      conversationId = d['conversation_id'] as String? ?? conversationId;
      return d['reply'] as String? ?? 'উত্তর পাওয়া যায়নি।';
    } on TimeoutException {
      throw Exception('Server সাড়া দিচ্ছে না (timeout).');
    } on http.ClientException {
      throw Exception('Server-এ পৌঁছানো যাচ্ছে না। ইন্টারনেট/URL চেক করো।');
    }
  }
}
