import 'package:flutter_secure_storage/flutter_secure_storage.dart';

class AppConfig {
  static const _s = FlutterSecureStorage();
  static const _envUrl = String.fromEnvironment('API_BASE_URL');

  static Future<String> baseUrl() async {
    final v = await _s.read(key: 'api_base_url');
    return (v != null && v.isNotEmpty) ? v : _envUrl;
  }

  static Future<void> setBaseUrl(String v) =>
      _s.write(key: 'api_base_url', value: v.trim().replaceAll(RegExp(r'/+$'), ''));

  static const modes = {
    'assistant': 'Assistant',
    'personal': 'Personal',
    'friend': 'Friend',
    'study': 'Study',
    'coder': 'Coder',
  };
  static Future<String> mode() async => (await _s.read(key: 'mode')) ?? 'assistant';
  static Future<void> setMode(String m) => _s.write(key: 'mode', value: m);
}
