import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'app_config.dart';

class OwnerUnlockService {
  static const _storage = FlutterSecureStorage();

  /// Returns null on success, otherwise an error message.
  Future<String?> unlock(String secretCode) async {
    final base = await AppConfig.baseUrl();
    if (base.isEmpty) return 'আগে Server URL সেভ করো।';
    try {
      final r = await http
          .post(Uri.parse('$base/v1/owner/unlock'),
              headers: {'Content-Type': 'application/json'},
              body: jsonEncode({'secret_code': secretCode}))
          .timeout(const Duration(seconds: 20));
      if (r.statusCode == 429) return 'অনেকবার চেষ্টা করেছ। পরে আবার চেষ্টা করো।';
      if (r.statusCode != 200) return 'কোড ভুল।';
      final d = jsonDecode(r.body) as Map<String, dynamic>;
      final t = d['owner_token'];
      if (t is! String || t.isEmpty) return 'Server থেকে ভুল উত্তর এসেছে।';
      await _storage.write(key: 'owner_token', value: t);
      return null;
    } catch (_) {
      return 'Server-এ পৌঁছানো যাচ্ছে না।';
    }
  }

  Future<String?> readOwnerToken() => _storage.read(key: 'owner_token');
  Future<void> lock() => _storage.delete(key: 'owner_token');
}
