import 'package:permission_handler/permission_handler.dart';

class PermissionService {
  static const all = [
    Permission.notification,
    Permission.microphone,
    Permission.contacts,
    Permission.photos,
  ];

  /// Shows the system permission dialogs one after another.
  static Future<Map<Permission, PermissionStatus>> requestAll() => all.request();

  static Future<bool> anyPermanentlyDenied() async {
    for (final p in all) {
      if (await p.isPermanentlyDenied) return true;
    }
    return false;
  }
}
