import 'package:url_launcher/url_launcher.dart';

/// Android/WhatsApp do not allow silent sending. This opens WhatsApp with the
/// message pre-filled; the user taps Send.
class WhatsAppService {
  static Future<bool> compose(String phone, String text) {
    final digits = phone.replaceAll(RegExp(r'[^0-9]'), '');
    final uri = Uri.parse('https://wa.me/$digits?text=${Uri.encodeComponent(text)}');
    return launchUrl(uri, mode: LaunchMode.externalApplication);
  }
}
