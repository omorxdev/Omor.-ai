"""Run after `flutter create`. Adds the permissions the release build needs.
The default release manifest has NO INTERNET permission - that is why the app
could not reach the server."""
import re, pathlib
p = pathlib.Path("android/app/src/main/AndroidManifest.xml")
x = p.read_text()
perms = """
    <uses-permission android:name="android.permission.INTERNET"/>
    <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE"/>
    <uses-permission android:name="android.permission.POST_NOTIFICATIONS"/>
    <uses-permission android:name="android.permission.RECORD_AUDIO"/>
    <uses-permission android:name="android.permission.READ_CONTACTS"/>
    <uses-permission android:name="android.permission.READ_MEDIA_IMAGES"/>
    <uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE" android:maxSdkVersion="32"/>
    <queries>
        <package android:name="com.whatsapp"/>
        <package android:name="com.whatsapp.w4b"/>
        <intent><action android:name="android.speech.RecognitionService"/></intent>
        <intent><action android:name="android.intent.action.TTS_SERVICE"/></intent>
        <intent><action android:name="android.intent.action.VIEW"/><data android:scheme="https"/></intent>
    </queries>
"""
if "android.permission.INTERNET" not in x:
    x = x.replace("<application", perms + "\n    <application", 1)
x = x.replace('android:label="developer_omor_ai"', 'android:label="DEVELOPER OMOR AI"')
p.write_text(x)
print("manifest patched")
