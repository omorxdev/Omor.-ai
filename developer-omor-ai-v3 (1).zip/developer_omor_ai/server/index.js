import express from 'express';
import crypto from 'node:crypto';

const { OWNER_SECRET, TOKEN_KEY, ANTHROPIC_API_KEY, MODEL = 'claude-sonnet-5-5', PORT = 3000 } = process.env;
if (!OWNER_SECRET || !TOKEN_KEY || !ANTHROPIC_API_KEY) throw new Error('Set OWNER_SECRET, TOKEN_KEY, ANTHROPIC_API_KEY');

const app = express();
app.set('trust proxy', 1);
app.use(express.json({ limit: '100kb' }));

const sign = (p) => crypto.createHmac('sha256', TOKEN_KEY).update(p).digest('base64url');
const same = (a, b) => { const x = Buffer.from(a), y = Buffer.from(b); return x.length === y.length && crypto.timingSafeEqual(x, y); };
const issue = () => { const exp = String(Date.now() + 7 * 864e5); return `${exp}.${sign(exp)}`; };
const valid = (t = '') => { const [exp, sig] = t.split('.'); return exp && sig && same(sig, sign(exp)) && Date.now() < Number(exp); };

const tries = new Map();
app.get('/v1/health', (_, res) => res.json({ ok: true }));

app.post('/v1/owner/unlock', (req, res) => {
  const now = Date.now(), t = (tries.get(req.ip) || []).filter((x) => now - x < 6e5);
  if (t.length >= 10) return res.status(429).json({ error: 'rate_limited' });
  t.push(now); tries.set(req.ip, t);
  const code = String(req.body?.secret_code ?? '');
  const h = (s) => crypto.createHash('sha256').update(s).digest('base64url');
  if (!same(h(code), h(OWNER_SECRET))) return res.status(401).json({ error: 'invalid' });
  res.json({ owner_token: issue(), expires_in: 7 * 86400 });
});

const BASE = 'Reply in the same language as the user (Bangla or English). ';
const MODES = {
  assistant: BASE + 'You are Omor AI, a clear, concise, helpful personal assistant.',
  personal: BASE + 'You are Omor AI in Personal mode: warm, informal and attentive. Help with the user\'s plans, habits and decisions, and give honest opinions.',
  friend: BASE + 'You are Omor AI in Friend mode: a cheerful, caring, playful companion. Be affectionate in tone, but stay honest, never claim to be human, never pressure the user to depend on you, and encourage real-life relationships.',
  study: BASE + 'You are Omor AI in Study mode: a patient tutor. Explain step by step, give examples, and check understanding.',
  coder: BASE + 'You are Omor AI in Coder mode: a senior engineer. Give working code, brief explanations, and point out bugs.',
};
const convos = new Map();
app.post('/v1/chat', async (req, res) => {
  if (!valid((req.headers.authorization || '').replace('Bearer ', ''))) return res.status(401).json({ error: 'unauthorized' });
  const message = String(req.body?.message ?? '').slice(0, 8000);
  if (!message) return res.status(400).json({ error: 'empty' });
  const id = req.body?.conversation_id || crypto.randomUUID();
  const history = convos.get(id) || [];
  history.push({ role: 'user', content: message });
  try {
    const r = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: { 'x-api-key': ANTHROPIC_API_KEY, 'anthropic-version': '2023-06-01', 'content-type': 'application/json' },
      body: JSON.stringify({ model: MODEL, max_tokens: 1024, system: MODES[req.body?.mode] || MODES.assistant, messages: history.slice(-20) }),
    });
    if (!r.ok) { console.error('upstream', r.status); return res.status(502).json({ error: 'upstream' }); }
    const reply = (await r.json()).content?.filter((c) => c.type === 'text').map((c) => c.text).join('\n') || '';
    history.push({ role: 'assistant', content: reply });
    convos.set(id, history.slice(-40));
    res.json({ reply, conversation_id: id });
  } catch (e) { console.error(e.message); res.status(502).json({ error: 'upstream' }); }
});

app.listen(PORT, () => console.log('listening', PORT));
